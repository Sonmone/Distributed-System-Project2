package activitystreamer.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.Gson;

import activitystreamer.util.*;

/*
 *ClassName: ClientSkeleton
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class ClientSkeleton extends Thread {
	//state the initializion of a client skeleton
	private static ClientSkeleton clientSolution;
	//state the initializion of a GUI
	private TextFrame textFrame;
	//create the socket
	private Socket socket;
	//state the initializion of a input data stream
	private DataInputStream in;
	//state the initializion of a output data stream
	private DataOutputStream out;
	//state the initializion of a buffer reader
	private BufferedReader inreader;
	//state the initializion of a print writer
	private PrintWriter outwriter;
	//use term to control a status of connection
	private boolean term=false;
	//represent whether the connection is openning
	private boolean open = false;
	//used to parser JSON type
	private JSONParser parser;
	//use gson to format strings to JSON
	private Gson gson = new Gson();

	/*
   *FunctionName: getInstance
	 *Parameter: null
	 *Return: Control
	 *Description: instantiate a ClientSkeleton class
	 */
	public static ClientSkeleton getInstance(){
		if(clientSolution==null){
			clientSolution = new ClientSkeleton();
		}
		return clientSolution;
	}

	/*
	 *ClassName: ClientSkeleton
	 *Version: 3.0
	 *Authors: Zhao, Song, Fan and Zhang
	 */
	public ClientSkeleton(){
		try {
			//create the socket of TCP to connect the target server
			this.socket = new Socket(Settings.getRemoteHostname(), Settings.getRemotePort());
			System.out.println("Successful connect to server");
			in = new DataInputStream(socket.getInputStream());
    	out = new DataOutputStream(socket.getOutputStream());
    	inreader = new BufferedReader( new InputStreamReader(in));
    	outwriter = new PrintWriter(out, true);
    	open = true;
		} catch (IOException e) {
			System.out.println("received exception, shutting down" + e);
			System.exit(0);
		}
		//make the client register or login
		if(!preConnectProcess(Settings.getUsername(), Settings.getSecret())){
			System.out.println("connection closed to "+Settings.socketAddress(socket));
		 	System.exit(0);
		}
		parser = new JSONParser();
		//open the GUI
		textFrame = new TextFrame();
		start();
	}

	/*
   *FunctionName: sendJsonObject
	 *Parameter: the message need to be sent
	 *Return: Null
	 *Description: parser the message to JSON type and send it
	 */
	@SuppressWarnings("unchecked")
	public synchronized void sendJsonObject(ClientMessage messageObj){
		//parser to JSON type
		String msg = gson.toJson(messageObj);
		System.out.println(msg);
		//send messages
		if(open){
			outwriter.println(msg);
			outwriter.flush();
		}
	}

	/*
   *FunctionName: sendActivityObject
	 *Parameter: the activity message need to be sent
	 *Return: Null
	 *Description: parser the activity message to JSON type and send it
	 */
	 public void sendActivityObject(JSONObject obj){
 		ClientMessage messageObj = new ClientMessage("ACTIVITY_MESSAGE", Settings.getUsername(), Settings.getSecret(), obj);
 		sendJsonObject(messageObj);
 	}

	/*
   *FunctionName: disconnect
	 *Parameter: Null
	 *Return: Null
	 *Description: close the connection by LOGOUT instruction
	 */
	public void disconnect(){
		if(open){
			System.out.println("closing connection "+Settings.socketAddress(socket));
			//send LOGOUT instruction
			ClientMessage messageObj = new ClientMessage("LOGOUT");
			sendJsonObject(messageObj);
			try {
				setTerm(true);
				inreader.close();
				out.close();
			} catch (IOException e) {
				// already closed?
				System.out.println("received exception closing the connection "+Settings.socketAddress(socket)+": "+e);
			}
		}
	}

	/*
	 *FunctionName: setTerm
	 *Parameter: true or false
	 *Return: null
	 *Description: announce set term with true or false which controls the connection status
	 */
	public final void setTerm(boolean t){
		term=t;
	}

	/*
   *FunctionName: run
	 *Parameter: null
	 *Return: Null
	 *Description: run the client
	 */
	public void run(){
		try {
			String data;
			while(!term && (data = inreader.readLine())!=null){
				term = process(data);
			}
			System.out.println("connection closed to "+Settings.socketAddress(socket));
			in.close();
		} catch (Exception e) {
			System.out.println("connection "+Settings.socketAddress(socket)+" closed with exception: "+e);
		}
		open=false;
		disconnect();
		System.exit(0);
	}

	/*
   *FunctionName: process
	 *Parameter: string message
	 *Return: true or false
	 *Description: process incomming instruction
	 */
	private boolean process(String msg){
		System.out.println(msg);
		JSONObject inJsonObj;
		boolean tempTerm = false;
		try{
			//get the concrete command
			String command = parseCommand(msg);
			//cope with REDIRECT instruction
			if(command.equals("REDIRECT")){
				RedirectMessage redictObj = gson.fromJson(msg, RedirectMessage.class);
				String info = String.format("this server is overload, you can retry on server %s:%d", redictObj.getHostname(), redictObj.getPort());
				System.out.println(info);
				tempTerm = true;
			}
			else{
				ServerMessage msgObj = gson.fromJson(msg, ServerMessage.class);
				switch(command){
					//cope with ACTIVITY_BROADCAST instruction
					case "ACTIVITY_BROADCAST":
						JSONObject acti = (JSONObject) parser.parse(msg);
						//print the message in GUI output window
						textFrame.setOutputText(acti);
						break;
					//cope with INVALID_MESSAGE instruction
					case "INVALID_MESSAGE":
						//print concrete invalid message
						System.out.println(msgObj.getInfo());
						tempTerm = true;
						break;
					//some other unknown mistakes
					default:
						System.out.println("Unknown mistake");
						tempTerm = true;
				}
			}
		} catch(ParseException e){
			System.out.println("receive corrupt message from server" + e);
			tempTerm = true;
		}
		return tempTerm;
	}

	/*
   *FunctionName: parseCommand
	 *Parameter: string message
	 *Return: concrete command
	 *Description: get the concrete command instruction
	 */
	private String parseCommand(String msg) throws ParseException {
		//parser the message to JSON type
		JSONObject msgObj = (JSONObject) parser.parse(msg);
		//get the command
		String command = (String) msgObj.get("command");
		return command;
	}

	/*
   *FunctionName: preConnectProcess
	 *Parameter: username and secret
	 *Return: true or false
	 *Description: process the register and login of the client
	 */
	private boolean preConnectProcess(String username, String secret){
		boolean successLogin = false;
		//process the user except anonymous user
		if (!username.equals("anonymous") && secret == null){
			//generate a secret
			secret = Settings.nextSecret();
			Settings.setSecret(secret);
			System.out.println(String.format("This is your password: %s", secret));
			ClientMessage registerMsg = new ClientMessage("REGISTER", username, secret);
			sendJsonObject(registerMsg);
			if(!responMsgCheck("REGISTER_SUCCESS")){
				return false;
			}
		}
		//login with username and secret
		successLogin = login(username, secret);
		return successLogin;
	}

	/*
   *FunctionName: login
	 *Parameter: username and secret
	 *Return: true or false
	 *Description: login the client with username and secret
	 */
	private boolean login(String username, String secret){
		//send LOGIN request for the server
		ClientMessage loginMsg = new ClientMessage("LOGIN", username, secret);
		sendJsonObject(loginMsg);
		//judge whether login successfully
		if(!responMsgCheck("LOGIN_SUCCESS")){
			return false;
		}
		return true;
	}

	/*
   *FunctionName: responMsgCheck
	 *Parameter: command
	 *Return: true or false
	 *Description: check the repsone message
	 */
	private boolean responMsgCheck(String command){
		ServerMessage responseMsg;
		try{
			String response = inreader.readLine();
			responseMsg = gson.fromJson(response, ServerMessage.class);
			if(responseMsg.getCommand().equals(command)){
				System.out.println(responseMsg.getInfo());
				return true;
			}
			else{
				if(!responseMsg.getCommand().equals("REDIRECT")){
					System.out.println("Exception:" + responseMsg.getInfo());
				}
				return false;
			}
		} catch (Exception e) {
  			System.out.println("received exception closing the connection " + e);
  		}
  		return false;
	}
}
